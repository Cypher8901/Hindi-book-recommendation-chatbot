"""
config.py

Centralized configuration for the Multilingual Hindi Book Recommendation
Chatbot. Reads settings from environment variables (via a .env file if
present) so nothing sensitive -- like an API key -- is hard-coded.

If no .env file exists yet (it's created in Phase 5), load_dotenv()
simply does nothing and every setting below falls back to its safe
default, so the app still starts.
"""

import os
import secrets

from dotenv import load_dotenv

load_dotenv()  # no-op if .env doesn't exist yet -- safe to call regardless

# ---------------------------------------------------------------------------
# Paths (relative to the project root, where app.py is run from)
# ---------------------------------------------------------------------------

DATA_DIR = os.getenv("DATA_DIR", "data")
MODEL_DIR = os.getenv("MODEL_DIR", "models")

BOOKS_CSV = os.path.join(DATA_DIR, "hindi_books.csv")
QUERIES_CSV = os.path.join(DATA_DIR, "chatbot_queries.csv")
REVIEWS_CSV = os.path.join(DATA_DIR, "hindi_book_reviews.csv")
GENRE_MAPPING_CSV = os.path.join(DATA_DIR, "genre_mapping.csv")

# ---------------------------------------------------------------------------
# Claude API (optional -- see chatbot.py for the fallback behaviour when
# this is unset, the anthropic package is missing, or a call fails)
# ---------------------------------------------------------------------------

ANTHROPIC_API_KEY = os.getenv("ANTHROPIC_API_KEY", "").strip()
CLAUDE_MODEL = os.getenv("CLAUDE_MODEL", "claude-sonnet-5")
CLAUDE_MAX_TOKENS = int(os.getenv("CLAUDE_MAX_TOKENS", "500"))

# The chatbot's behaviour must be dataset-only: Claude is only ever
# allowed to rephrase results that were already retrieved from the CSV
# files. This system prompt is passed with every Claude call.
CLAUDE_SYSTEM_PROMPT = (
    "You are a multilingual book recommendation assistant. Use ONLY the "
    "supplied book records. Never invent book titles, authors, ratings, "
    "genres, reviews, or descriptions. If information is unavailable, "
    "say so. Respond in the same language as the user's message."
)

# ---------------------------------------------------------------------------
# Recommendation engine settings
# ---------------------------------------------------------------------------

TOP_N_RECOMMENDATIONS = int(os.getenv("TOP_N_RECOMMENDATIONS", "5"))
MAX_AUTHOR_RESULTS = int(os.getenv("MAX_AUTHOR_RESULTS", "10"))
MAX_REVIEW_SAMPLES = int(os.getenv("MAX_REVIEW_SAMPLES", "2"))

# ---------------------------------------------------------------------------
# Conversation memory
# ---------------------------------------------------------------------------

# How many of the most recently shown books to remember per session, so
# that a vague follow-up like "इनमें से सबसे अच्छी कौन सी है?" or "What is
# the rating of this book?" can be resolved against them.
MAX_CONTEXT_BOOKS = int(os.getenv("MAX_CONTEXT_BOOKS", "5"))

# How many turns of raw conversation history to keep per session (used
# only for the /chat response's "history" field -- NOT re-sent into the
# recommendation engine on every message, per the project's instruction
# to keep the recommendation engine's input small and deliberate).
MAX_HISTORY_TURNS = int(os.getenv("MAX_HISTORY_TURNS", "10"))

# ---------------------------------------------------------------------------
# Flask settings
# ---------------------------------------------------------------------------

FLASK_HOST = os.getenv("FLASK_HOST", "127.0.0.1")
FLASK_PORT = int(os.getenv("FLASK_PORT", "5000"))
FLASK_DEBUG = os.getenv("FLASK_DEBUG", "True").lower() in ("1", "true", "yes")

# Used to sign the session cookie that holds conversation context. If not
# set via .env, a random key is generated at process startup -- fine for
# local development (sessions just reset on restart), but for anything
# beyond a college project this should be set explicitly in .env so
# sessions survive a server restart.
FLASK_SECRET_KEY = os.getenv("FLASK_SECRET_KEY", "").strip() or secrets.token_hex(32)
if not os.getenv("FLASK_SECRET_KEY", "").strip():
    print(
        "Warning: FLASK_SECRET_KEY not set in .env -- using a random key "
        "for this run. Sessions (conversation memory) will reset every "
        "time the server restarts. Set FLASK_SECRET_KEY in .env to avoid this."
    )
