"""
chatbot.py

Orchestrates one chat turn:
    user message
      -> nlp.detect_language / nlp.detect_intent   (Phase 2, unmodified)
      -> recommendation.BookRecommender             (Phase 2, unmodified)
      -> local, template-based response grounded ONLY in retrieved rows
      -> optional Claude rephrasing of that same grounded answer
      -> response dict + updated conversation context

CRITICAL RULE ENFORCED THROUGHOUT THIS FILE:
Every response is built from data actually returned by
recommendation.BookRecommender (which itself only reads the CSV files).
Claude, when used, is given the already-retrieved book records and is
explicitly instructed (system prompt in config.py) to rephrase only --
never to add a book, author, rating, or review that wasn't retrieved.
If Claude is unavailable or fails for any reason, the local template
response is used as-is, so the chatbot always works without the API.

Conversation memory: a small `context` dict (see `resolve_book_targets`)
carries forward the ids of the most recently shown books. This is what
lets a vague follow-up like "What is the rating of this book?" or
"इनमें से सबसे अच्छी कौन सी है?" resolve to something -- the "referring
to the previous results" behaviour required by the project spec.
Important honesty note: when a follow-up refers to *multiple* books
from context (e.g. "इनमें से सबसे अच्छी कौन सी है?" = "which of these is
best?"), this file does NOT invent a "best" pick -- the dataset has no
real ratings to rank by, so picking a "best" book would itself be a
kind of fabrication. Instead, it honestly reports the same requested
information (rating/review/info) for each candidate book and lets the
user judge, which is the only truthful thing to do with this data.
"""

import csv
import json

import config
from recommendation import BookRecommender
import nlp


def load_genre_display_names(path=config.GENRE_MAPPING_CSV):
    """
    Build a small {hindi_genre: english_genre} lookup purely for nicer
    English-language phrasing (e.g. "रोमांस (Romance)"). This reads the
    same genre_mapping.csv already used by nlp.py -- it does not modify
    or duplicate any matching logic, just adds a display label.
    """
    mapping = {}
    try:
        with open(path, encoding="utf-8") as f:
            for row in csv.DictReader(f):
                hg = row.get("hindi_genre", "").strip()
                eg = row.get("english_genre", "").strip()
                if hg and eg:
                    mapping[hg] = eg
    except FileNotFoundError:
        pass
    return mapping


class Chatbot:
    """
    Stateless with respect to conversation history: each call to
    `process_message` takes the current `context` dict explicitly and
    returns an updated one. app.py is responsible for persisting that
    context (e.g. in the Flask session) between requests.
    """

    def __init__(self, recommender: BookRecommender):
        self.recommender = recommender
        self.genre_display_names = load_genre_display_names()
        self._claude_client = self._init_claude_client()

    # ------------------------------------------------------------------
    # Optional Claude client setup
    # ------------------------------------------------------------------

    def _init_claude_client(self):
        """
        Returns an initialized anthropic client, or None if the API key
        is not set, the `anthropic` package is not installed, or client
        creation fails for any reason. The chatbot is fully functional
        with a None client -- it just skips the rephrasing step.
        """
        if not config.ANTHROPIC_API_KEY:
            return None
        try:
            import anthropic
        except ImportError:
            print(
                "Note: 'anthropic' package not installed -- Claude "
                "rephrasing is disabled, using local response templates only."
            )
            return None
        try:
            return anthropic.Anthropic(api_key=config.ANTHROPIC_API_KEY)
        except Exception as e:
            print(f"Note: Claude client could not be initialized ({e}); "
                  "using local response templates only.")
            return None

    def _generate_claude_response(self, language, intent, local_response_text, books):
        """
        Ask Claude to rephrase `local_response_text` naturally, giving it
        ONLY the already-retrieved `books` as source material. Returns
        None (meaning: use the local template response instead) if
        Claude is not configured or the call fails for any reason --
        this must never raise or block the chat.
        """
        if self._claude_client is None:
            return None
        try:
            book_json = json.dumps(books, ensure_ascii=False)
            user_content = (
                f"User language: {language}\n"
                f"Detected intent: {intent}\n"
                f"A local system already computed this factually correct "
                f"answer using ONLY the book dataset:\n\"{local_response_text}\"\n\n"
                f"Book records retrieved from the dataset (JSON array, use "
                f"ONLY these records, do not add, remove, or alter any "
                f"field):\n{book_json}\n\n"
                "Rephrase the answer above in a natural, warm, conversational "
                "way for the user. Do not introduce any book, author, rating, "
                "genre, or review not present in the JSON above. Respond in "
                "the same language as 'User language'."
            )
            message = self._claude_client.messages.create(
                model=config.CLAUDE_MODEL,
                max_tokens=config.CLAUDE_MAX_TOKENS,
                system=config.CLAUDE_SYSTEM_PROMPT,
                messages=[{"role": "user", "content": user_content}],
            )
            text_parts = [
                block.text for block in message.content
                if getattr(block, "type", "") == "text"
            ]
            text = "".join(text_parts).strip()
            return text or None
        except Exception as e:
            # Covers: missing/invalid key, network failure, rate limits,
            # SDK errors, etc. -- always degrade gracefully.
            print(f"Note: Claude API call failed ({e}); "
                  "falling back to local response template.")
            return None

    # ------------------------------------------------------------------
    # Conversation context helpers
    # ------------------------------------------------------------------

    def resolve_book_targets(self, extracted_title, context):
        """
        Decide which real book(s) (from the dataset) the current message
        is actually about, combining what nlp.py extracted from THIS
        message with the conversation `context` from PREVIOUS messages.

        Returns a list of book dicts (0, 1, or more items):
          - If `extracted_title` was resolved by nlp.py, look it up and
            return exactly that one book (current message is explicit).
          - Else, fall back to the books listed in context["last_books"]
            (most recently shown/discussed books), so a follow-up like
            "What is the rating of this book?" still works.
          - If neither is available, returns [] -- the caller must then
            ask the user to specify a book rather than guessing.
        """
        if extracted_title:
            matches = self.recommender.search_by_title(extracted_title)
            if matches:
                return matches[:1]

        last_ids = (context or {}).get("last_books", [])
        resolved = []
        for book_id in last_ids:
            book = self.recommender.get_book_by_id(book_id)
            if book:
                resolved.append(book)
        return resolved

    @staticmethod
    def _update_context(books):
        """Build the context dict to persist after showing `books`."""
        ids = [b["book_id"] for b in books][:config.MAX_CONTEXT_BOOKS]
        return {"last_books": ids}

    # ------------------------------------------------------------------
    # Response text helpers (kept as small, explicit templates so the
    # logic is easy to walk through in a viva -- no hidden formatting)
    # ------------------------------------------------------------------

    def _genre_label(self, hindi_genre, language):
        """
        Genre display label for the RESPONSE SENTENCE only (book cards
        keep the dataset's own Hindi genre value untouched -- see
        module notes). Hindi responses use the Hindi genre name as-is;
        English responses use ONLY the English genre name (lowercased,
        for natural sentence flow), never both mixed together like the
        old "सामाजिक (Social)" label.
        """
        if language == "English":
            english = self.genre_display_names.get(hindi_genre)
            if english:
                return english.lower()
        return hindi_genre

    def _no_match_text(self, language):
        if language == "Hindi":
            return ("मुझे आपके अनुरोध से मेल खाती कोई पुस्तक नहीं मिली। "
                    "कृपया कोई दूसरा genre, लेखक या पुस्तक का नाम आज़माएँ।")
        return "I couldn't find a matching book. Try another genre, author, or book title."

    def _no_book_specified_text(self, language):
        if language == "Hindi":
            return "कृपया बताएं कि आप किस किताब के बारे में पूछ रहे हैं।"
        return "Please tell me which book you're asking about."

    def _rating_status_text(self, book, language):
        """
        The book-level `rating` column is empty for every row in the
        current dataset, so this will currently always return the
        "not available" message -- that is correct behaviour given the
        real data, not a bug. If a future dataset version fills in real
        ratings, the `rating_available` branch below already handles it.
        """
        if book["rating_available"]:
            if language == "Hindi":
                return f"'{book['title']}' की रेटिंग {book['rating']} है।"
            return f"The rating of '{book['title']}' is {book['rating']}."
        if language == "Hindi":
            return f"'{book['title']}': इस पुस्तक की रेटिंग हमारे dataset में उपलब्ध नहीं है।"
        return f"'{book['title']}': The rating for this book is not available in our dataset."

    def _review_summary_text(self, book, language):
        summary = self.recommender.get_reviews_summary(book["book_id"])
        if not summary or summary["review_count"] == 0:
            if language == "Hindi":
                return f"'{book['title']}' के लिए dataset में कोई समीक्षा उपलब्ध नहीं है।"
            return f"No reviews are available in the dataset for '{book['title']}'."

        counts = summary["sentiment_counts"]
        parts_hi = []
        parts_en = []
        for sentiment, label_hi, label_en in [
            ("Positive", "सकारात्मक", "positive"),
            ("Neutral", "तटस्थ", "neutral"),
            ("Negative", "नकारात्मक", "negative"),
        ]:
            if counts.get(sentiment):
                parts_hi.append(f"{counts[sentiment]} {label_hi}")
                parts_en.append(f"{counts[sentiment]} {label_en}")

        avg = summary["average_review_rating"]
        if language == "Hindi":
            text = f"'{book['title']}' के लिए कुल {summary['review_count']} समीक्षाएं हैं"
            if parts_hi:
                text += " (" + ", ".join(parts_hi) + ")"
            if avg is not None:
                text += f"; औसत पाठक समीक्षा स्कोर {avg:.1f}/5 है"
            text += ("। ध्यान दें: ये समीक्षाएं सिंथेटिक (कृत्रिम रूप से बनाई गई) "
                     "डेटा पर आधारित हैं, वास्तविक पाठक समीक्षाएं नहीं हैं।")
        else:
            text = f"'{book['title']}' has {summary['review_count']} reviews in the dataset"
            if parts_en:
                text += " (" + ", ".join(parts_en) + ")"
            if avg is not None:
                text += f"; the average reader review score is {avg:.1f}/5"
            text += (". Note: these reviews are based on SYNTHETIC (artificially "
                     "generated) data, not real reader reviews.")
        return text

    # ------------------------------------------------------------------
    # Intent handlers -- each returns (response_text, books_list)
    # ------------------------------------------------------------------

    def _handle_greeting(self, language):
        if language == "Hindi":
            text = ("नमस्ते! मैं आपकी हिंदी किताबों में मदद करने वाला सहायक हूँ। "
                    "आप मुझसे किताब की सिफारिश, genre, लेखक, रेटिंग या समीक्षा के बारे में पूछ सकते हैं।")
        else:
            text = ("Hello! I'm your Hindi book recommendation assistant. "
                    "Ask me for a book recommendation, a genre, an author, a rating, or reviews.")
        return text, []

    def _handle_help(self, language):
        if language == "Hindi":
            text = ("मैं इनमें मदद कर सकता हूँ: किताब की सिफारिश, genre के अनुसार किताबें, "
                    "लेखक के अनुसार खोज, किताब खोजना, किताब की जानकारी, रेटिंग, और समीक्षाएं। "
                    "बस मुझसे पूछें, जैसे 'मुझे रहस्य की किताब बताओ' या 'गोदान की रेटिंग क्या है?'")
        else:
            text = ("I can help with: book recommendations, genre-based suggestions, "
                    "author search, book search, book information, ratings, and reviews. "
                    "Just ask, e.g. 'Show me mystery books' or 'What is the rating of Godan?'")
        return text, []

    def _handle_goodbye(self, language):
        if language == "Hindi":
            text = "धन्यवाद! फिर मिलेंगे। पढ़ने का आनंद लें!"
        else:
            text = "Thank you! See you again. Happy reading!"
        return text, []

    def _handle_genre_recommendation(self, genre, language):
        books = self.recommender.recommend(genre=genre, top_n=config.TOP_N_RECOMMENDATIONS)
        label = self._genre_label(genre, language)
        if not books:
            if language == "Hindi":
                return f"क्षमा करें, '{label}' श्रेणी में इस समय dataset में कोई किताब उपलब्ध नहीं है।", []
            return f"Sorry, there are currently no {label} books in our dataset.", []

        # Short intro only -- the per-book title/author/genre/description
        # is shown by the book cards below, so it isn't repeated here.
        if language == "Hindi":
            text = f"आपके लिए कुछ {label} किताबें हैं:"
        else:
            text = f"Here are some {label} books for you:"
        return text, books

    def _handle_author_search(self, author, language):
        books = self.recommender.search_by_author(author, top_n=config.MAX_AUTHOR_RESULTS)
        if not books:
            return self._no_match_text(language), []

        if language == "Hindi":
            text = f"{author} की किताबें यहाँ हैं:"
        else:
            text = f"Here are the books by {author}:"
        return text, books

    def _handle_book_search(self, title, language):
        if not title:
            return self._no_match_text(language), []
        books = self.recommender.search_by_title(title)
        if not books:
            return self._no_match_text(language), []
        if language == "Hindi":
            text = "यह रही किताब की जानकारी:"
        else:
            text = "Here's the book information:"
        return text, books[:1]

    def _handle_book_information(self, title, context, language):
        targets = self.resolve_book_targets(title, context)
        if not targets:
            return self._no_book_specified_text(language), []
        if len(targets) == 1:
            text = "यह रही किताब की जानकारी:" if language == "Hindi" else "Here's the book information:"
            return text, targets

        # Multiple candidate books from context (an ambiguous follow-up
        # like "tell me about these") -- the cards below show each one;
        # this stays a short header rather than a duplicated text block.
        if language == "Hindi":
            text = "आपने हाल ही में इन किताबों के बारे में बात की थी:"
        else:
            text = "You've recently been discussing these books:"
        return text, targets

    def _handle_rating_query(self, title, context, language):
        targets = self.resolve_book_targets(title, context)
        if not targets:
            return self._no_book_specified_text(language), []
        if len(targets) == 1:
            return self._rating_status_text(targets[0], language), targets

        # Multiple candidates from context: cannot honestly pick a
        # "best" one (no real ratings exist to rank by), so report the
        # rating status of each -- see module docstring.
        lines = [self._rating_status_text(b, language) for b in targets]
        header = ("आपने हाल ही में कई किताबों के बारे में पूछा था; प्रत्येक की रेटिंग स्थिति यहाँ है:\n"
                  if language == "Hindi"
                  else "You've recently asked about multiple books; here is the rating status for each:\n")
        return header + "\n".join(lines), targets

    def _handle_review_query(self, title, context, language):
        targets = self.resolve_book_targets(title, context)
        if not targets:
            return self._no_book_specified_text(language), []
        if len(targets) == 1:
            return self._review_summary_text(targets[0], language), targets

        lines = [self._review_summary_text(b, language) for b in targets]
        header = ("आपने हाल ही में कई किताबों के बारे में पूछा था; प्रत्येक की समीक्षा यहाँ है:\n\n"
                  if language == "Hindi"
                  else "You've recently asked about multiple books; here are the reviews for each:\n\n")
        return header + "\n\n".join(lines), targets

    def _handle_book_recommendation(self, language):
        # No genre/author/title extracted -- this is recommend()'s
        # "no criteria" fallback (see recommendation.py docstring): real
        # dataset rows, but with no ranking signal behind the selection.
        books = self.recommender.recommend(top_n=config.TOP_N_RECOMMENDATIONS)
        if language == "Hindi":
            text = "आपके लिए कुछ हिंदी किताबें हैं:"
        else:
            text = "Here are some Hindi books you might like:"
        return text, books

    def _response_matches_language(self, text, language, books=None):
        """
        Check whether a piece of GENERATED RESPONSE text is actually
        written in `language`, for validating Claude's output before
        trusting it.

        This is deliberately NOT the same check as nlp.detect_language()
        (left completely unmodified, per the project's NLP logic being
        off-limits). nlp.detect_language() treats ANY Devanagari
        character as "Hindi" -- the right call for a short user query,
        but wrong here: a fully correct ENGLISH response legitimately
        contains real Devanagari book titles and author names (e.g.
        "Here are some books: गोदान by मुंशी प्रेमचंद"), and when several
        books are listed, those real Devanagari proper nouns can easily
        out-number the English connecting words by raw character count.

        So this strips out the real book titles/author names (from
        `books`, the SAME retrieved records that were given to Claude)
        first, and only then checks which script dominates what's left
        -- i.e. Claude's own sentence structure and connecting words,
        not the real proper nouns it was required to keep untranslated.
        """
        remainder = text
        for book in (books or []):
            for field in ("title", "author"):
                value = book.get(field)
                if value:
                    remainder = remainder.replace(value, " ")

        devanagari_count = sum(1 for ch in remainder if "\u0900" <= ch <= "\u097F")
        latin_count = sum(1 for ch in remainder if ch.isascii() and ch.isalpha())

        if language == "Hindi":
            return devanagari_count > 0 and devanagari_count >= latin_count
        # language == "English"
        return latin_count >= devanagari_count

    # ------------------------------------------------------------------
    # Main entry point
    # ------------------------------------------------------------------

    def process_message(self, message, context=None):
        """
        Process one user message and return (response_dict, new_context).

        response_dict matches the shape used by app.py's /chat route:
            {
                "language": "Hindi" | "English",
                "intent": str,
                "response": str,
                "books": [ ...book dicts... ],
                "claude_used": bool,
            }
        """
        context = context or {}

        if not message or not message.strip():
            language = "English"
            text = "Please enter a message."
            return {
                "language": language, "intent": "empty_message",
                "response": text, "books": [], "claude_used": False,
            }, context

        language = nlp.detect_language(message)

        intent_result = nlp.detect_intent(
            message,
            self.recommender.known_authors,
            self.recommender.known_titles,
            self.recommender.genre_keyword_map,
            self.recommender.roman_author_map,
            self.recommender.roman_title_map,
        )
        intent = intent_result["intent"]
        genre = intent_result["genre"]
        author = intent_result["author"]
        book_title = intent_result["book_title"]

        books = []
        new_context = context

        if intent == "greeting":
            text, books = self._handle_greeting(language)
        elif intent == "help":
            text, books = self._handle_help(language)
        elif intent == "goodbye":
            text, books = self._handle_goodbye(language)
        elif intent == "genre_recommendation":
            text, books = self._handle_genre_recommendation(genre, language)
        elif intent == "author_search":
            text, books = self._handle_author_search(author, language)
        elif intent == "book_search":
            text, books = self._handle_book_search(book_title, language)
        elif intent == "book_information":
            text, books = self._handle_book_information(book_title, context, language)
        elif intent == "rating_query":
            text, books = self._handle_rating_query(book_title, context, language)
        elif intent == "review_query":
            text, books = self._handle_review_query(book_title, context, language)
        elif intent == "book_recommendation":
            text, books = self._handle_book_recommendation(language)
        else:
            # Defensive fallback -- nlp.detect_intent always returns one
            # of the known intents, but this keeps the chatbot from ever
            # crashing on an unexpected value.
            text, books = self._no_match_text(language), []

        claude_text = self._generate_claude_response(language, intent, text, books)

        # Guarantee requirement: response language must always match the
        # detected input language. Claude is asked (via the system prompt
        # in config.py) to respond in the same language, but an LLM can
        # still ignore that instruction -- so we verify its output with
        # _response_matches_language() before trusting it, rather than
        # trusting it blindly. If Claude's rephrasing doesn't match, we
        # discard it and use the local template text instead, which is
        # language-correct by construction. This means correctness never
        # depends on the Claude API being configured or cooperating.
        claude_used = False
        if claude_text and self._response_matches_language(claude_text, language, books):
            final_text = claude_text
            claude_used = True
        else:
            final_text = text

        if books:
            new_context = self._update_context(books)

        response = {
            "language": language,
            "intent": intent,
            "response": final_text,
            "books": books,
            "claude_used": claude_used,
        }
        return response, new_context
