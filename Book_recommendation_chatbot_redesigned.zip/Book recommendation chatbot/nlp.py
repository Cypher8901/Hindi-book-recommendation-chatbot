"""
nlp.py

Language detection, intent detection, and entity extraction (genre /
author / book title) for the Multilingual Hindi Book Recommendation
Chatbot.

Design notes (for viva explanation):
- Language detection: langdetect first, with an explicit Devanagari
  Unicode-range check as an override. langdetect is unreliable on very
  short strings (e.g. single words), so if the text contains any
  Devanagari characters we trust that signal over langdetect's guess.
- Intent detection is RULE-BASED (keyword + pattern matching), not a
  trained classifier. The keyword lists below were derived by reading
  the actual queries in data/chatbot_queries.csv (see project Phase 1
  inspection) -- they are not guesses.
- Entity extraction (genre/author/title) always matches against the
  REAL values present in the dataset (genre_mapping.csv, and the
  author/title lists passed in from hindi_books.csv). Nothing here
  invents a genre, author, or title that isn't already in the data.
- A lightweight, approximate Devanagari -> Roman transliteration is
  included so that a Latin-script query like "Godan" or "Premchand"
  can still be fuzzy-matched against Devanagari titles/authors like
  "गोदान" / "मुंशी प्रेमचंद". This is NOT a linguistically complete
  transliteration scheme -- it exists purely to improve fuzzy matching
  and is documented as approximate.
"""

import csv
import difflib
import re

try:
    from langdetect import detect as _langdetect_detect
    from langdetect import LangDetectException
except ImportError:  # pragma: no cover - exercised only if langdetect missing
    _langdetect_detect = None
    LangDetectException = Exception


# ---------------------------------------------------------------------------
# Language detection
# ---------------------------------------------------------------------------

# Unicode block for Devanagari script (covers Hindi).
DEVANAGARI_RANGE = (0x0900, 0x097F)


def contains_devanagari(text):
    """Return True if `text` contains at least one Devanagari character."""
    for ch in text:
        if DEVANAGARI_RANGE[0] <= ord(ch) <= DEVANAGARI_RANGE[1]:
            return True
    return False


def detect_language(text):
    """
    Detect whether `text` is Hindi or English.

    Strategy:
    1. If the text contains any Devanagari characters, classify as
       'Hindi' immediately. This is a hard, reliable signal and takes
       priority over langdetect (which can misfire on short or mixed
       text).
    2. Otherwise, try langdetect. If it reports Hindi ('hi') or fails
       (e.g. text too short, or langdetect not installed), fall back
       to 'English' -- reasonable since non-Devanagari text with no
       other signal is almost always English or a Romanized query.

    Returns: 'Hindi' or 'English'
    """
    if not text or not text.strip():
        return "English"

    if contains_devanagari(text):
        return "Hindi"

    if _langdetect_detect is not None:
        try:
            code = _langdetect_detect(text)
            if code == "hi":
                return "Hindi"
            return "English"
        except LangDetectException:
            return "English"

    # langdetect not installed and no Devanagari found -> default English
    return "English"


# ---------------------------------------------------------------------------
# Approximate Devanagari -> Roman transliteration (for fuzzy matching only)
# ---------------------------------------------------------------------------

_VOWEL_SIGNS = {
    "\u093E": "aa", "\u093F": "i", "\u0940": "ii", "\u0941": "u",
    "\u0942": "uu", "\u0943": "ri", "\u0947": "e", "\u0948": "ai",
    "\u094B": "o", "\u094C": "au",
}
_INDEPENDENT_VOWELS = {
    "\u0905": "a", "\u0906": "aa", "\u0907": "i", "\u0908": "ii",
    "\u0909": "u", "\u090A": "uu", "\u090B": "ri", "\u090F": "e",
    "\u0910": "ai", "\u0913": "o", "\u0914": "au",
}
_CONSONANTS = {
    "\u0915": "k", "\u0916": "kh", "\u0917": "g", "\u0918": "gh",
    "\u0919": "ng", "\u091A": "ch", "\u091B": "chh", "\u091C": "j",
    "\u091D": "jh", "\u091E": "ny", "\u091F": "t", "\u0920": "th",
    "\u0921": "d", "\u0922": "dh", "\u0923": "n", "\u0924": "t",
    "\u0925": "th", "\u0926": "d", "\u0927": "dh", "\u0928": "n",
    "\u092A": "p", "\u092B": "ph", "\u092C": "b", "\u092D": "bh",
    "\u092E": "m", "\u092F": "y", "\u0930": "r", "\u0932": "l",
    "\u0935": "v", "\u0936": "sh", "\u0937": "sh", "\u0938": "s",
    "\u0939": "h",
}
_VIRAMA = "\u094D"
_ANUSVARA_CHANDRABINDU = {"\u0902": "n", "\u0901": "n", "\u0903": "h"}


def transliterate_devanagari_to_roman(text):
    """
    Produce an APPROXIMATE Roman-script rendering of a Devanagari
    string, for fuzzy-matching purposes only (not a display-quality
    transliteration).

    Approach: walk character by character. A consonant carries an
    inherent 'a' sound unless followed by a vowel sign (matra) or a
    virama (halant, which suppresses the vowel). The trailing inherent
    'a' at the very end of the word is dropped, matching common Hindi
    Romanization practice (e.g. "गोदान" -> "godaan", not "godaana").
    """
    result = []
    i = 0
    n = len(text)
    while i < n:
        ch = text[i]
        if ch in _CONSONANTS:
            roman = _CONSONANTS[ch]
            nxt = text[i + 1] if i + 1 < n else ""
            if nxt == _VIRAMA:
                result.append(roman)
                i += 2
                continue
            if nxt in _VOWEL_SIGNS:
                result.append(roman + _VOWEL_SIGNS[nxt])
                i += 2
                continue
            # no matra follows -> inherent 'a'
            result.append(roman + "a")
            i += 1
            continue
        if ch in _INDEPENDENT_VOWELS:
            result.append(_INDEPENDENT_VOWELS[ch])
            i += 1
            continue
        if ch in _ANUSVARA_CHANDRABINDU:
            result.append(_ANUSVARA_CHANDRABINDU[ch])
            i += 1
            continue
        if ch == " ":
            result.append(" ")
            i += 1
            continue
        # punctuation / non-Devanagari characters: pass through
        if not (DEVANAGARI_RANGE[0] <= ord(ch) <= DEVANAGARI_RANGE[1]):
            result.append(ch)
        i += 1

    roman = "".join(result)
    # Drop a single trailing inherent 'a' (common Hindi Romanization convention)
    if roman.endswith("a") and not roman.endswith("aa"):
        roman = roman[:-1]
    return roman.strip()


# ---------------------------------------------------------------------------
# Text normalization
# ---------------------------------------------------------------------------

def tokenize(text):
    """
    Split `text` into tokens on whitespace and common punctuation only.

    This is deliberately NOT a regex \\b/\\w-based split: Devanagari
    vowel signs (matras) and the virama are Unicode "Mark" characters,
    not "word" characters, so Python's \\b can incorrectly report a
    word boundary in the MIDDLE of an ordinary Devanagari word (e.g.
    between "स" and the following matra in "नमस्ते"). Splitting only on
    actual separator characters (space, punctuation) avoids that
    entirely and is also simpler to explain: "a word is whatever sits
    between two separators."
    """
    return [t for t in re.split(r"[\s,।?!\"'().:;]+", text) if t]


def _phrase_in_tokens(phrase, tokens):
    """
    Return True if `phrase` (a keyword, possibly multiple words)
    appears as a contiguous run inside `tokens` (the tokenized text).
    Both are compared token-for-token, not via substring/regex, which
    is what makes this safe for Devanagari (see `tokenize` docstring).
    """
    phrase_tokens = tokenize(phrase)
    if not phrase_tokens:
        return False
    n = len(phrase_tokens)
    for i in range(len(tokens) - n + 1):
        if tokens[i:i + n] == phrase_tokens:
            return True
    return False


def normalize_text(text):
    """
    Lowercase Latin characters (case-insensitive English matching),
    strip surrounding quote characters, and collapse extra whitespace.
    Devanagari characters are left completely untouched.
    """
    text = text.strip()
    # Strip common quote characters used around titles in the dataset
    text = text.strip("'\"\u2018\u2019\u201C\u201D")
    text = re.sub(r"\s+", " ", text)
    # Lowercase only ASCII letters; Devanagari has no case, so this is safe.
    return "".join(c.lower() if "A" <= c <= "Z" else c for c in text)


def extract_quoted_text(text):
    """
    Return the content between the first pair of quote characters
    (straight or curly single/double quotes) if present, else None.
    Used to pull out a book title from queries like "'गोदान' की रेटिंग क्या है?"
    """
    match = re.search(
        r"['\"\u2018\u2019\u201C\u201D]([^'\"\u2018\u2019\u201C\u201D]+)['\"\u2018\u2019\u201C\u201D]",
        text,
    )
    if match:
        return match.group(1).strip()
    return None


# ---------------------------------------------------------------------------
# Genre mapping (loaded from the real genre_mapping.csv)
# ---------------------------------------------------------------------------

def load_genre_keyword_map(genre_mapping_path="data/genre_mapping.csv"):
    """
    Build a lookup dict mapping every Hindi/English keyword (lowercased)
    to its corresponding hindi_genre value, using ONLY what is present
    in genre_mapping.csv. No genre or keyword is invented here.

    Returns: dict[str keyword] -> str hindi_genre
    """
    keyword_map = {}
    with open(genre_mapping_path, encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            hindi_genre = row["hindi_genre"].strip()
            if not hindi_genre:
                continue
            # the hindi_genre value itself is also a valid keyword
            keyword_map[hindi_genre] = hindi_genre
            for kw in row.get("hindi_keywords", "").split(","):
                kw = kw.strip()
                if kw:
                    keyword_map[kw] = hindi_genre
            for kw in row.get("english_keywords", "").split(","):
                kw = kw.strip().lower()
                if kw:
                    keyword_map[kw] = hindi_genre
            eng_genre = row.get("english_genre", "").strip().lower()
            if eng_genre:
                keyword_map[eng_genre] = hindi_genre
    return keyword_map


def extract_genre(text, genre_keyword_map):
    """
    Search `text` for any known genre keyword (Hindi or English) and
    return the matching hindi_genre value, or None if no genre keyword
    is present. Longer keywords are checked first so that e.g.
    "प्रेम कहानी" matches before a shorter overlapping keyword would.
    """
    normalized = normalize_text(text)
    tokens = tokenize(normalized)
    # check longest keywords first to avoid partial/short-word false matches
    for keyword in sorted(genre_keyword_map.keys(), key=len, reverse=True):
        keyword_norm = keyword.lower() if keyword.isascii() else keyword
        if keyword_norm and _phrase_in_tokens(keyword_norm, tokens):
            return genre_keyword_map[keyword]
    return None


# ---------------------------------------------------------------------------
# Author / title matching against the REAL dataset values
# ---------------------------------------------------------------------------

def match_author(text, known_authors, roman_author_map=None, cutoff=0.72):
    """
    Find the best-matching author name from `known_authors` (the actual
    unique author list from hindi_books.csv) that appears in `text`.

    Matching order:
    1. Whole-word Devanagari substring match of the FULL author name
       (handles a query that includes the complete name as written in
       the dataset).
    2. Whole-word Devanagari match of a single distinctive name token
       (skipping common honorifics like "मुंशी"/"आचार्य") -- handles a
       query that only gives the surname, e.g. "प्रेमचंद" without
       "मुंशी".
    3. Fuzzy match against the approximate Roman transliteration (full
       name or individual token), for Latin-script queries like
       "premchand".

    Returns the matched author string (exactly as it appears in the
    dataset) or None.
    """
    text_tokens = tokenize(text)

    # 1. whole-word match of the complete author name
    for author in sorted(known_authors, key=len, reverse=True):
        if author and _phrase_in_tokens(author, text_tokens):
            return author

    # 2. whole-word match of a single distinctive token of the author name
    for author in sorted(known_authors, key=len, reverse=True):
        for token in author.split():
            if token in _AUTHOR_HONORIFIC_TOKENS or len(token) < 3:
                continue
            if token in text_tokens:
                return author

    # 3. fuzzy match via approximate transliteration (for Latin-script queries)
    if roman_author_map:
        normalized = normalize_text(text)
        candidates = _latin_candidates(normalized)
        match = _best_fuzzy_match(candidates, roman_author_map, cutoff)
        if match:
            return match
    return None


def match_title(text, known_titles, roman_title_map=None, cutoff=0.72):
    """
    Find the best-matching book title from `known_titles` (the actual
    title list from hindi_books.csv).

    Matching order:
    1. If the query has quoted text (e.g. 'गोदान'), try to match that
       exactly or fuzzily against known titles first.
    2. Direct substring match of any known title inside the raw text.
    3. Fuzzy match via approximate Roman transliteration, for queries
       like "Godan" typed in Latin script.

    Returns the matched title string (exactly as in the dataset) or None.
    """
    quoted = extract_quoted_text(text)
    if quoted:
        if quoted in known_titles:
            return quoted
        close = difflib.get_close_matches(quoted, known_titles, n=1, cutoff=0.6)
        if close:
            return close[0]

    text_tokens = tokenize(text)
    for title in sorted(known_titles, key=len, reverse=True):
        if title and _phrase_in_tokens(title, text_tokens):
            return title

    if roman_title_map:
        normalized = normalize_text(text)
        candidates = _latin_candidates(normalized)
        if quoted:
            candidates.append(normalize_text(quoted))
        match = _best_fuzzy_match(candidates, roman_title_map, cutoff)
        if match:
            return match
    return None


def build_roman_lookup(values):
    """
    Given a list of real Devanagari strings (titles or authors), build
    a dict mapping {approximate_roman_form: original_string}, used for
    fuzzy-matching Latin-script user queries.

    Both the full-string transliteration AND each individual word's
    transliteration are indexed. This matters for multi-word author
    names: a query like "Show me books by Premchand" only supplies the
    surname, not the honorific "मुंशी" -- without per-token indexing,
    "premchand" would never fuzzy-match the full-name roman form
    "munshii premachand" closely enough to pass the similarity cutoff.
    """
    lookup = {}
    for value in values:
        full_roman = transliterate_devanagari_to_roman(value).lower()
        if full_roman and full_roman not in lookup:
            lookup[full_roman] = value
        for token in value.split():
            token_roman = transliterate_devanagari_to_roman(token).lower()
            if token_roman and token_roman not in lookup:
                lookup[token_roman] = value
    return lookup



# Common English function/query words that show up constantly in the
# chatbot_queries.csv templates ("show me", "what is", "the rating of",
# etc.). These are excluded from fuzzy-match candidates because short
# stopwords like "show" can otherwise accidentally resemble a short
# transliterated Devanagari name (e.g. "show" vs. "osho") closely
# enough to pass a naive similarity cutoff.
_ENGLISH_STOPWORDS = {
    "a", "an", "the", "is", "of", "by", "me", "to", "in", "on", "for",
    "this", "that", "what", "how", "good", "show", "tell", "give",
    "recommend", "suggest", "about", "information", "book", "books",
    "rating", "review", "reviews", "hindi", "novel", "read", "want",
    "looking", "find", "best", "written", "written", "did", "people",
    "like", "readers", "say", "are", "and",
}


def _latin_candidates(normalized_text):
    """
    Extract candidate Latin-script substrings from `normalized_text` to
    test against a roman lookup table: every individual word, plus
    2-word and 3-word windows (to catch multi-word titles/authors typed
    in Roman script) -- excluding common English query stopwords, which
    are never themselves a book title or author name.

    (A single greedy regex that grabs the whole Latin phrase as one
    candidate is NOT enough -- e.g. for "what is the rating of godan",
    comparing the entire 6-word phrase against a single title's roman
    form scores far too low. Testing each word/window individually is
    what makes single embedded words like "godan" matchable.)
    """
    words = re.findall(r"[a-zA-Z]+", normalized_text)
    candidates = set(w for w in words if w not in _ENGLISH_STOPWORDS)
    for n in (2, 3):
        for i in range(len(words) - n + 1):
            window = words[i:i + n]
            if all(w in _ENGLISH_STOPWORDS for w in window):
                continue
            candidates.add(" ".join(window))
    return [c for c in candidates if len(c) >= 3]


def _best_fuzzy_match(candidates, roman_map, cutoff=0.72):
    """
    Try every candidate string against every key in `roman_map` and
    return the original (real dataset) value for the single best-scoring
    match at or above `cutoff`, or None if nothing qualifies.

    Short strings get a stricter effective cutoff: edit-distance-based
    similarity ratios are unreliable for very short strings (a handful
    of shared letters can push a 4-letter word over a 0.72 ratio purely
    by chance, as happened with "show" vs. the transliterated "osho").
    """
    best_ratio = 0.0
    best_value = None
    for chunk in candidates:
        effective_cutoff = cutoff if len(chunk) >= 6 else max(cutoff, 0.85)
        for roman_key, original in roman_map.items():
            if len(roman_key) < 6 and len(chunk) < 6:
                key_cutoff = max(effective_cutoff, 0.85)
            else:
                key_cutoff = effective_cutoff
            ratio = difflib.SequenceMatcher(None, chunk, roman_key).ratio()
            if ratio >= key_cutoff and ratio > best_ratio:
                best_ratio = ratio
                best_value = original
    return best_value


# A small set of Hindi honorific/title words that commonly prefix an
# author's real name in this dataset (e.g. "मुंशी प्रेमचंद"). These are
# skipped when looking for a single distinctive name-token in the user's
# text, so that a query naming only "प्रेमचंद" (without "मुंशी") still
# matches. This list was built by inspecting the actual multi-word
# author names in hindi_books.csv -- it is not a generic guess.
_AUTHOR_HONORIFIC_TOKENS = {"मुंशी", "आचार्य", "डॉ", "डॉ.", "श्री", "स्वामी", "पंडित"}


# ---------------------------------------------------------------------------
# Intent keyword lists
# (derived from reading data/chatbot_queries.csv during Phase 1 inspection)
# ---------------------------------------------------------------------------

GREETING_KEYWORDS = [
    "नमस्ते", "हैलो", "आप कैसे हैं", "शुभ प्रभात",
    "hi", "hello", "how are you", "good morning",
]

HELP_KEYWORDS = [
    "मदद", "उपयोग कैसे करें",
    "help", "how do i use", "how to use",
]

GOODBYE_KEYWORDS = [
    "अलविदा", "बाय", "फिर मिलेंगे",
    "bye", "goodbye", "see you",
]

RATING_KEYWORDS = [
    "रेटिंग", "कितनी अच्छी किताब",
    "rating", "how good is",
]

REVIEW_KEYWORDS = [
    "पाठकों के क्या विचार", "पाठकों के विचार", "पसंद आई", "समीक्षा",
    "reviews", "did people like", "readers say", "how are the reviews",
]

BOOK_INFO_KEYWORDS = [
    "की कहानी क्या है", "किताब के बारे में जानकारी", "के बारे में बताओ",
    "tell me about", "give me information", "information about",
]

AUTHOR_SEARCH_KEYWORDS = [
    "की किताबें", "द्वारा लिखी", "लिखी गई किताबें", "सबसे अच्छी किताब",
    "books by", "written by", "book by", "best book by",
]

RECOMMENDATION_KEYWORDS = [
    "सुझाओ", "बताओ", "चाहिए", "दिखाओ", "पढ़ना है",
    "recommend", "suggest", "show me", "looking for", "want to read",
]

# A user referring back to previously shown books and asking which is
# "best" (e.g. "इनमें से सबसे अच्छी कौन सी है?" / "which of these is
# best?") cannot be honestly answered by picking a "best" book -- the
# dataset has no real ratings to rank by. Routing this to rating_query
# with no book_title lets the conversation-context fallback in
# chatbot.py kick in, which honestly reports the rating status of each
# recently-discussed book instead of fabricating a "winner".
CONTEXT_REFERENCE_PHRASES = ["इनमें से", "among these", "of these", "these books"]
BEST_QUALITY_PHRASES = ["सबसे अच्छी", "सबसे अच्छा", "बेहतर", "best", "better"]


# ---------------------------------------------------------------------------
# Main intent detection
# ---------------------------------------------------------------------------

def _contains_any(text_normalized, keyword_list):
    """
    Whole-word/whole-phrase match via tokenization (see `tokenize`),
    so that short keywords (e.g. English "hi") do not false-positive
    match inside a longer unrelated word (e.g. "hindi"), and the same
    for short Hindi keywords (e.g. "प्रेम" inside "प्रेमचंद").
    """
    tokens = tokenize(text_normalized)
    for kw in keyword_list:
        kw_check = kw.lower() if kw.isascii() else kw
        if kw_check and _phrase_in_tokens(kw_check, tokens):
            return True
    return False


def detect_intent(text, known_authors, known_titles, genre_keyword_map,
                   roman_author_map=None, roman_title_map=None):
    """
    Rule-based intent detection over the actual intent set used in
    data/chatbot_queries.csv:

        book_recommendation, genre_recommendation, author_search,
        book_search, rating_query, review_query, book_information,
        greeting, help, goodbye

    Priority order (most specific / least ambiguous first):
      1. greeting / help / goodbye  -- short, distinctive phrases
      2. rating_query               -- explicit rating keyword
      3. review_query               -- explicit review keyword
      4. book_information           -- explicit "tell me about" style keyword
      5. author_search              -- a known author name is present
      6. genre_recommendation       -- a known genre keyword is present
      7. book_search                -- a known title is present, with no
                                        recommendation/greeting keyword
      8. book_recommendation        -- generic "recommend/suggest" language
      9. book_search (fallback)     -- fuzzy title match as last resort

    Returns a dict:
        {
            "intent": str,
            "genre": str or None,
            "author": str or None,
            "book_title": str or None,
        }
    All extracted values are guaranteed to be real values already
    present in the dataset (or None) -- nothing here is invented.
    """
    normalized = normalize_text(text)
    result = {"intent": None, "genre": None, "author": None, "book_title": None}

    if _contains_any(normalized, GREETING_KEYWORDS):
        result["intent"] = "greeting"
        return result

    if _contains_any(normalized, HELP_KEYWORDS):
        result["intent"] = "help"
        return result

    if _contains_any(normalized, GOODBYE_KEYWORDS):
        result["intent"] = "goodbye"
        return result

    # A "which of these is best?" style follow-up, referring back to
    # previously shown books -- see CONTEXT_REFERENCE_PHRASES docstring
    # above. book_title is deliberately left None so the caller's
    # conversation-context fallback resolves which books are meant.
    if (_contains_any(normalized, CONTEXT_REFERENCE_PHRASES)
            and _contains_any(normalized, BEST_QUALITY_PHRASES)):
        result["intent"] = "rating_query"
        return result

    title = match_title(text, known_titles, roman_title_map)

    if _contains_any(normalized, RATING_KEYWORDS):
        result["intent"] = "rating_query"
        result["book_title"] = title
        return result

    if _contains_any(normalized, REVIEW_KEYWORDS):
        result["intent"] = "review_query"
        result["book_title"] = title
        return result

    if _contains_any(normalized, BOOK_INFO_KEYWORDS):
        result["intent"] = "book_information"
        result["book_title"] = title
        return result

    author = match_author(text, known_authors, roman_author_map)
    if author:
        result["intent"] = "author_search"
        result["author"] = author
        return result
    if _contains_any(normalized, AUTHOR_SEARCH_KEYWORDS):
        # The message clearly asks for an author's books ("books by...",
        # "...की किताबें"), but the named author isn't in our dataset.
        # Still route to author_search (with author=None) so the
        # handler gives an honest "no match" response instead of
        # silently switching to an unrelated generic recommendation.
        result["intent"] = "author_search"
        return result

    genre = extract_genre(text, genre_keyword_map)
    if genre:
        result["intent"] = "genre_recommendation"
        result["genre"] = genre
        return result

    if title and not _contains_any(normalized, RECOMMENDATION_KEYWORDS):
        result["intent"] = "book_search"
        result["book_title"] = title
        return result

    if _contains_any(normalized, RECOMMENDATION_KEYWORDS):
        result["intent"] = "book_recommendation"
        return result

    if title:
        result["intent"] = "book_search"
        result["book_title"] = title
        return result

    # Nothing matched: default to a general recommendation so the
    # chatbot still responds usefully instead of failing silently.
    result["intent"] = "book_recommendation"
    return result
