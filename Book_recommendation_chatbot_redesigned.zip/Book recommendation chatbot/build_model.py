"""
build_model.py

Builds the TF-IDF vectorizer and matrix used by recommendation.py, and
saves them to models/ so that app.py / recommendation.py can load them
ONCE at startup instead of rebuilding the model on every chat message.

Run this once (and again any time hindi_books.csv changes):
    python build_model.py

This script only READS data/hindi_books.csv -- it never writes to it.

Important preservation note: TfidfVectorizer is configured with
`strip_accents=None` (the default is also None, but it is set
explicitly here for clarity). Devanagari vowel signs (matras) are
technically combining marks, and an accent-stripping normalizer could
corrupt them -- so this setting is deliberate, not an oversight.
"""

import os
import pickle

import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer

DATA_PATH = "data/hindi_books.csv"
MODEL_DIR = "models"


def load_books(data_path=DATA_PATH):
    """
    Load hindi_books.csv and validate that the columns this script
    depends on actually exist -- fails loudly rather than silently
    working around a missing column.
    """
    if not os.path.exists(data_path):
        raise FileNotFoundError(
            f"Could not find '{data_path}'. This script does not create "
            "or modify the dataset -- make sure the real CSV is in place."
        )

    df = pd.read_csv(data_path, dtype=str, keep_default_na=False)

    required_columns = {"book_id", "title", "author", "genre", "search_text"}
    missing = required_columns - set(df.columns)
    if missing:
        raise ValueError(
            f"hindi_books.csv is missing required column(s): {missing}. "
            "build_model.py was written against the actual inspected "
            "schema and will not guess a replacement column."
        )

    df["book_id"] = df["book_id"].astype(str)
    return df


def build_tfidf_model(df):
    """
    Build a TF-IDF vectorizer + matrix over the dataset's existing
    `search_text` column (title + author + genre + description,
    already concatenated when the dataset was created). We do NOT
    reconstruct search_text here -- we use exactly what's in the CSV,
    per the project instruction to only use fields that actually exist.

    A handful of rows could in principle have an empty search_text
    (e.g. if title/author/genre/description were all blank); none do
    in the current dataset, but we guard against it so the vectorizer
    doesn't silently drop rows.
    """
    search_texts = df["search_text"].tolist()
    empty_count = sum(1 for t in search_texts if not t.strip())
    if empty_count:
        # Replace only for vectorization purposes -- not written back to
        # the CSV, and not treated as if it were real book content.
        search_texts = [t if t.strip() else " " for t in search_texts]
        print(f"Warning: {empty_count} row(s) had an empty search_text; "
              "using a blank placeholder token for vectorization only "
              "(no book information was invented).")

    vectorizer = TfidfVectorizer(
        strip_accents=None,   # preserve Devanagari combining marks (matras)
        lowercase=True,       # safe: Devanagari has no case, only affects Latin text
        token_pattern=r"(?u)\b\w+\b",  # Unicode word chars, includes Devanagari
        ngram_range=(1, 1),
        min_df=1,
    )
    tfidf_matrix = vectorizer.fit_transform(search_texts)
    return vectorizer, tfidf_matrix


def save_model(vectorizer, tfidf_matrix, book_ids, model_dir=MODEL_DIR):
    """Save the vectorizer, matrix, and matching book_id order to disk."""
    os.makedirs(model_dir, exist_ok=True)

    with open(os.path.join(model_dir, "tfidf_vectorizer.pkl"), "wb") as f:
        pickle.dump(vectorizer, f)

    with open(os.path.join(model_dir, "tfidf_matrix.pkl"), "wb") as f:
        pickle.dump(tfidf_matrix, f)

    # Save the exact row order (list of book_id strings) so
    # recommendation.py can map tfidf_matrix rows back to the correct
    # book without relying on pandas index alignment implicitly.
    with open(os.path.join(model_dir, "tfidf_book_ids.pkl"), "wb") as f:
        pickle.dump(book_ids, f)


def main():
    print("Loading dataset from '{}' ...".format(DATA_PATH))
    df = load_books()
    print(f"Loaded {len(df)} books.")

    print("Building TF-IDF model over the existing 'search_text' column ...")
    vectorizer, tfidf_matrix = build_tfidf_model(df)

    vocab_size = len(vectorizer.vocabulary_)
    print(f"TF-IDF matrix shape: {tfidf_matrix.shape} "
          f"({tfidf_matrix.shape[0]} books x {vocab_size} vocabulary terms)")

    book_ids = df["book_id"].tolist()
    save_model(vectorizer, tfidf_matrix, book_ids)

    print(f"Saved model files to '{MODEL_DIR}/':")
    print(f"  - {MODEL_DIR}/tfidf_vectorizer.pkl")
    print(f"  - {MODEL_DIR}/tfidf_matrix.pkl")
    print(f"  - {MODEL_DIR}/tfidf_book_ids.pkl")
    print("Done. Flask (via recommendation.py) will load these files once "
          "at startup instead of rebuilding the model per request.")


if __name__ == "__main__":
    main()
