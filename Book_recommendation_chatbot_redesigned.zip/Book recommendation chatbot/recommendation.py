"""
recommendation.py

Dataset-driven recommendation engine for the Multilingual Hindi Book
Recommendation Chatbot.

CRITICAL RULE ENFORCED THROUGHOUT THIS FILE:
Every book returned by this module is a row read directly out of
data/hindi_books.csv. Nothing is generated, invented, or hallucinated.
If no matching row exists, the relevant function returns an empty list
/ None, and it is the caller's (chatbot.py's) job to phrase a clear
"not found" message -- this file never manufactures a placeholder book.

Scoring design (explained here for viva purposes):
    final_score = (0.5 * text_similarity)
                + (0.3 * genre_match)
                + (0.2 * author_or_title_match)
    A book-level "rating score" term is intentionally NOT added to this
    formula: the `rating` column in hindi_books.csv is empty for every
    row in the current dataset, so a rating-based weight would always
    contribute zero and add noise, not signal. The weighting logic is
    still written generically (see `_rating_score`) so that if a future
    version of the dataset fills in real ratings, re-enabling that term
    is a one-line change -- it is not wired into the active score.

Text similarity uses TF-IDF + cosine similarity over the dataset's own
`search_text` column (title + author + genre + description), loaded
from a model built once by build_model.py and saved under models/.
This file NEVER rebuilds the TF-IDF model itself -- see build_model.py.
"""

import os
import pickle

import pandas as pd
from sklearn.metrics.pairwise import cosine_similarity

import nlp


class BookRecommender:
    """
    Loads hindi_books.csv and the pre-built TF-IDF model, and provides
    genre/author/title/text-based search and a combined scored
    recommendation function.
    """

    def __init__(self, books_csv_path="data/hindi_books.csv",
                 reviews_csv_path="data/hindi_book_reviews.csv",
                 model_dir="models"):
        if not os.path.exists(books_csv_path):
            raise FileNotFoundError(
                f"Dataset not found at '{books_csv_path}'. "
                "This module never invents book data, so it cannot run "
                "without the real dataset file."
            )

        self.books_df = pd.read_csv(books_csv_path, dtype=str, keep_default_na=False)
        self.books_df["book_id"] = self.books_df["book_id"].astype(str)

        self.reviews_df = None
        if os.path.exists(reviews_csv_path):
            self.reviews_df = pd.read_csv(reviews_csv_path, dtype=str, keep_default_na=False)
            self.reviews_df["book_id"] = self.reviews_df["book_id"].astype(str)

        # Pre-built TF-IDF artifacts (created by build_model.py). We load
        # them once here and never rebuild them on a per-request basis.
        vectorizer_path = os.path.join(model_dir, "tfidf_vectorizer.pkl")
        matrix_path = os.path.join(model_dir, "tfidf_matrix.pkl")
        ids_path = os.path.join(model_dir, "tfidf_book_ids.pkl")

        if not (os.path.exists(vectorizer_path) and os.path.exists(matrix_path)
                and os.path.exists(ids_path)):
            raise FileNotFoundError(
                "TF-IDF model files not found in '{}'. Run build_model.py "
                "first (see README) -- the model is built once, offline, "
                "not rebuilt on every chatbot request.".format(model_dir)
            )

        with open(vectorizer_path, "rb") as f:
            self.vectorizer = pickle.load(f)
        with open(matrix_path, "rb") as f:
            self.tfidf_matrix = pickle.load(f)
        with open(ids_path, "rb") as f:
            self.tfidf_book_ids = pickle.load(f)  # row order of tfidf_matrix

        # Real, unique values from the dataset -- used for author/title
        # matching in nlp.py. Never supplemented with invented values.
        self.known_authors = sorted(set(
            a for a in self.books_df["author"].tolist() if a.strip()
        ))
        self.known_titles = sorted(set(
            t for t in self.books_df["title"].tolist() if t.strip()
        ))
        self.roman_author_map = nlp.build_roman_lookup(self.known_authors)
        self.roman_title_map = nlp.build_roman_lookup(self.known_titles)
        self.genre_keyword_map = nlp.load_genre_keyword_map()

        # quick lookup: book_id -> row index in books_df
        self._id_to_index = {
            bid: idx for idx, bid in enumerate(self.books_df["book_id"])
        }
        # quick lookup: book_id -> row index in tfidf_matrix
        self._id_to_tfidf_row = {
            bid: i for i, bid in enumerate(self.tfidf_book_ids)
        }

    # ------------------------------------------------------------------
    # Basic row access
    # ------------------------------------------------------------------

    def get_book_by_id(self, book_id):
        """Return a single book dict for `book_id`, or None if not found."""
        book_id = str(book_id)
        idx = self._id_to_index.get(book_id)
        if idx is None:
            return None
        return self._row_to_dict(self.books_df.iloc[idx])

    def _row_to_dict(self, row):
        """
        Convert a pandas row into a plain dict, being explicit about
        which optional fields are actually present so the caller (UI)
        can decide how to render missing data -- never filling in a
        placeholder value here.
        """
        description = row.get("description", "").strip()
        rating = row.get("rating", "").strip()
        year = row.get("publication_year", "").strip()
        return {
            "book_id": row["book_id"],
            "title": row["title"],
            "author": row["author"],
            "genre": row["genre"],
            "description": description if description else None,
            "description_available": bool(description),
            "rating": rating if rating else None,
            "rating_available": bool(rating),
            "publication_year": year if year else None,
            "language": row.get("language", ""),
        }

    # ------------------------------------------------------------------
    # Genre / author / title search
    # ------------------------------------------------------------------

    def search_by_genre(self, hindi_genre, top_n=5):
        """
        Return up to `top_n` real books whose `genre` column exactly
        matches `hindi_genre`. Returns [] if the genre has no books
        (this happens for genres present in genre_mapping.csv but with
        zero books currently in the dataset, e.g. हॉरर).
        """
        if not hindi_genre:
            return []
        matches = self.books_df[self.books_df["genre"] == hindi_genre]
        return [self._row_to_dict(r) for _, r in matches.head(top_n).iterrows()]

    def search_by_author(self, author, top_n=10):
        """Return up to `top_n` real books by an exact author match."""
        if not author:
            return []
        matches = self.books_df[self.books_df["author"] == author]
        return [self._row_to_dict(r) for _, r in matches.head(top_n).iterrows()]

    def search_by_title(self, title, top_n=5):
        """
        Return real books whose title matches `title` exactly, or (if
        no exact match) fuzzy-matches it via nlp.match_title. Returns
        [] if nothing matches -- never returns a fabricated book.
        """
        if not title:
            return []
        exact = self.books_df[self.books_df["title"] == title]
        if not exact.empty:
            return [self._row_to_dict(r) for _, r in exact.head(top_n).iterrows()]

        matched_title = nlp.match_title(
            title, self.known_titles, self.roman_title_map
        )
        if matched_title:
            exact = self.books_df[self.books_df["title"] == matched_title]
            return [self._row_to_dict(r) for _, r in exact.head(top_n).iterrows()]
        return []

    # ------------------------------------------------------------------
    # TF-IDF text similarity
    # ------------------------------------------------------------------

    def _text_similarity_scores(self, query_text):
        """
        Compute cosine similarity between `query_text` and every book's
        search_text, using the pre-built TF-IDF vectorizer/matrix.

        Returns a dict {book_id: similarity_score} for every book in
        the dataset (score may be 0.0 for books with no vocabulary
        overlap -- that is a valid real score, not a placeholder).
        """
        query_vector = self.vectorizer.transform([query_text])
        similarities = cosine_similarity(query_vector, self.tfidf_matrix)[0]
        return {
            book_id: float(similarities[i])
            for i, book_id in enumerate(self.tfidf_book_ids)
        }

    @staticmethod
    def _rating_score(rating_str):
        """
        Convert a book's `rating` field into a 0-1 score for the
        weighted formula. Returns 0.0 when rating is blank (which is
        every row in the current dataset) -- this function exists so
        the scoring formula is future-proof, not to fabricate a score.
        """
        if not rating_str or not rating_str.strip():
            return 0.0
        try:
            value = float(rating_str)
            return max(0.0, min(1.0, value / 5.0))
        except ValueError:
            return 0.0

    # ------------------------------------------------------------------
    # Combined, weighted recommendation
    # ------------------------------------------------------------------

    def recommend(self, query_text=None, genre=None, author=None,
                   book_title=None, top_n=5):
        """
        Rank real books from hindi_books.csv using a weighted
        combination of:
            0.5 * TF-IDF text similarity to `query_text`
            0.3 * genre match (1.0 if book's genre == `genre`, else 0.0)
            0.2 * author-or-title match (1.0 if book's author == `author`
                  OR book's title == `book_title`, else 0.0)
        A book-level rating term is available (`_rating_score`) but not
        included in the active weights -- see module docstring.

        Only books already present in the dataset can appear in the
        result; there is no code path that constructs a new book.
        """
        text_scores = {}
        if query_text and query_text.strip():
            text_scores = self._text_similarity_scores(query_text)

        has_criteria = bool(
            (query_text and query_text.strip()) or genre or author or book_title
        )

        scored = []
        for _, row in self.books_df.iterrows():
            book_id = row["book_id"]
            text_score = text_scores.get(book_id, 0.0)
            genre_score = 1.0 if (genre and row["genre"] == genre) else 0.0
            match_score = 1.0 if (
                (author and row["author"] == author)
                or (book_title and row["title"] == book_title)
            ) else 0.0

            final_score = (0.5 * text_score) + (0.3 * genre_score) + (0.2 * match_score)

            # If the caller supplied at least one criterion (genre, author,
            # title, or free text), a book with zero relevance on ALL of
            # them is not a real recommendation for this query -- drop it
            # rather than let it pad out top_n in arbitrary dataset order.
            if has_criteria and final_score <= 0.0:
                continue

            scored.append((final_score, book_id, row))

        # NOTE: if no criteria were supplied at all (query_text, genre,
        # author, and book_title all empty/None), every score is 0.0 and
        # `scored` above would be empty due to the filter -- so in that
        # specific case we skip filtering and fall through to returning
        # the first `top_n` dataset rows as-is. This is real, unmodified
        # data (never fabricated), but it carries NO ranking signal; the
        # caller (chatbot.py) should only rely on this path as a last
        # resort (e.g. a fully generic "recommend me a book" with no
        # extractable genre/author/title) and should say so if relevant.
        if not has_criteria:
            scored = [
                (0.0, row["book_id"], row)
                for _, row in self.books_df.head(top_n).iterrows()
            ]

        scored.sort(key=lambda t: t[0], reverse=True)
        results = [self._row_to_dict(row) for score, book_id, row in scored[:top_n]]
        return results

    # ------------------------------------------------------------------
    # Reviews (from hindi_book_reviews.csv -- synthetic data, clearly labeled)
    # ------------------------------------------------------------------

    def get_reviews_summary(self, book_id, max_samples=2):
        """
        Return a summary of the REAL review rows for `book_id` from
        hindi_book_reviews.csv:
            - sentiment counts (Positive/Neutral/Negative)
            - average of the review-level `rating` column
            - up to `max_samples` sample review texts

        IMPORTANT: this average is explicitly labeled as coming from
        synthetic review data (source_type=synthetic in the CSV). It
        must never be presented to the user as the book's official
        rating -- callers should label it as a "reader review average
        (synthetic data)", not "rating".

        Returns None if there are no reviews for this book_id.
        """
        if self.reviews_df is None:
            return None
        book_id = str(book_id)
        rows = self.reviews_df[self.reviews_df["book_id"] == book_id]
        if rows.empty:
            return None

        sentiment_counts = rows["sentiment"].value_counts().to_dict()
        ratings = [float(r) for r in rows["rating"] if r.strip()]
        avg_rating = sum(ratings) / len(ratings) if ratings else None
        samples = rows["review_text"].head(max_samples).tolist()
        is_synthetic = bool((rows["source_type"] == "synthetic").all())

        return {
            "review_count": int(len(rows)),
            "sentiment_counts": sentiment_counts,
            "average_review_rating": avg_rating,
            "sample_reviews": samples,
            "synthetic": is_synthetic,
        }
