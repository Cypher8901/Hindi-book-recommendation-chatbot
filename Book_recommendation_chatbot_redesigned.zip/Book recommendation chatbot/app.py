"""
app.py

Flask backend for the Multilingual Hindi Book Recommendation Chatbot.

Startup sequence (once, not per-request):
    1. Load config.py settings.
    2. Load recommendation.BookRecommender -- this reads hindi_books.csv
       / hindi_book_reviews.csv and the pre-built TF-IDF model files
       from models/ (built by build_model.py). If the model files are
       missing, this fails immediately at startup with a clear message
       telling you to run build_model.py first, instead of silently
       trying to rebuild the model on the first request.
    3. Wrap it in a chatbot.Chatbot instance.

Per-request conversation memory is kept in the Flask session (a signed
cookie, see config.FLASK_SECRET_KEY) as a small dict, e.g.
{"last_books": ["1", "5"]}. Nothing about past turns is sent back into
the recommendation engine wholesale -- only that small context dict.

Routes:
    GET  /                a placeholder page for now (Phase 4 adds the
                           real templates/index.html -- if it's not
                           there yet, this route degrades gracefully)
    POST /chat             the chatbot endpoint
    GET  /books             list/filter real books from the dataset
    GET  /book/<book_id>    a single book's full details + reviews
"""

import sys

from flask import Flask, jsonify, render_template, request, session

import config
from chatbot import Chatbot
from recommendation import BookRecommender

app = Flask(__name__)
app.secret_key = config.FLASK_SECRET_KEY

# ---------------------------------------------------------------------------
# Startup: load the dataset + pre-built model ONCE
# ---------------------------------------------------------------------------

try:
    recommender = BookRecommender(
        books_csv_path=config.BOOKS_CSV,
        reviews_csv_path=config.REVIEWS_CSV,
        model_dir=config.MODEL_DIR,
    )
except FileNotFoundError as e:
    print("=" * 70)
    print("STARTUP ERROR: could not load the dataset or TF-IDF model.")
    print(str(e))
    print("If this is about missing model files, run:")
    print("    python build_model.py")
    print("before starting the Flask app.")
    print("=" * 70)
    sys.exit(1)

chatbot = Chatbot(recommender)


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------

@app.route("/")
def index():
    """
    Renders templates/index.html. Phase 3 (this file) is being built
    before Phase 4 (the frontend), so if the template doesn't exist
    yet, fall back to a minimal placeholder instead of crashing --
    once Phase 4 adds templates/index.html this route needs no changes.
    """
    try:
        return render_template("index.html")
    except Exception:
        return (
            "<h1>Multilingual AI-Based Book Recommendation Chatbot Using NLP</h1>"
            "<p>Backend is running. The chat UI (templates/index.html) has not "
            "been added yet -- POST to /chat to talk to the chatbot directly, "
            "e.g. with curl or Postman.</p>",
            200,
        )


@app.route("/chat", methods=["POST"])
def chat():
    """
    Body:  {"message": "मुझे एक रोमांटिक किताब सुझाओ"}
    Reply: {"language": ..., "intent": ..., "response": ..., "books": [...], "claude_used": ...}
    """
    if not request.is_json:
        return jsonify({"error": "Request body must be JSON with a 'message' field."}), 400

    data = request.get_json(silent=True)
    if data is None:
        return jsonify({"error": "Invalid or empty JSON body."}), 400

    message = data.get("message", "")
    if not isinstance(message, str) or not message.strip():
        return jsonify({"error": "The 'message' field is required and cannot be empty."}), 400

    context = session.get("context", {})

    try:
        response, new_context = chatbot.process_message(message, context)
    except Exception as e:
        # Never let an unexpected error take down the chat -- log it
        # server-side and return a safe, honest message to the client.
        print(f"Error while processing message: {e}")
        return jsonify({
            "error": "Something went wrong while processing your message. Please try again."
        }), 500

    session["context"] = new_context
    return jsonify(response), 200


@app.route("/books", methods=["GET"])
def list_books():
    """
    List/filter real books straight from hindi_books.csv.
    Query params (all optional):
        genre   -- exact Hindi genre value (see genre_mapping.csv)
        author  -- exact author name
        q       -- free-text search (uses the TF-IDF engine)
        limit   -- max number of results (default: config.TOP_N_RECOMMENDATIONS * 4)
    """
    genre = request.args.get("genre", "").strip() or None
    author = request.args.get("author", "").strip() or None
    query = request.args.get("q", "").strip() or None
    try:
        limit = int(request.args.get("limit", config.TOP_N_RECOMMENDATIONS * 4))
        if limit <= 0:
            raise ValueError
    except ValueError:
        return jsonify({"error": "'limit' must be a positive integer."}), 400

    if genre or author or query:
        books = recommender.recommend(
            query_text=query, genre=genre, author=author, top_n=limit
        )
    else:
        books = [
            recommender._row_to_dict(row)
            for _, row in recommender.books_df.head(limit).iterrows()
        ]

    return jsonify({"count": len(books), "books": books}), 200


@app.route("/book/<book_id>", methods=["GET"])
def book_detail(book_id):
    """Full details for one real book, plus its (synthetic) review summary."""
    book = recommender.get_book_by_id(book_id)
    if not book:
        return jsonify({"error": f"No book found with book_id '{book_id}'."}), 404

    reviews = recommender.get_reviews_summary(book_id, max_samples=config.MAX_REVIEW_SAMPLES)
    return jsonify({"book": book, "reviews": reviews}), 200


# ---------------------------------------------------------------------------
# Error handlers
# ---------------------------------------------------------------------------

@app.errorhandler(404)
def not_found(e):
    return jsonify({"error": "The requested resource was not found."}), 404


@app.errorhandler(405)
def method_not_allowed(e):
    return jsonify({"error": "That HTTP method is not allowed for this route."}), 405


@app.errorhandler(500)
def internal_error(e):
    return jsonify({"error": "An internal server error occurred."}), 500


if __name__ == "__main__":
    print(f"Dataset loaded: {len(recommender.books_df)} books, "
          f"{len(recommender.known_authors)} authors.")
    print(f"Starting Flask app on http://{config.FLASK_HOST}:{config.FLASK_PORT}/")
    app.run(host=config.FLASK_HOST, port=config.FLASK_PORT, debug=config.FLASK_DEBUG)
