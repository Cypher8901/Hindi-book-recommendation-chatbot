# -*- coding: utf-8 -*-
"""
validate_dataset.py

Validates all CSV files in data/ for the Multilingual AI-Based Book
Recommendation Chatbot project.

Run:
    python3 validate_dataset.py
"""

import csv
import os
import sys
from collections import Counter

DATA_DIR = "data"

MIN_BOOKS = 300
TARGET_BOOKS_LOW = 300
TARGET_BOOKS_HIGH = 400
TARGET_HI_QUERIES = 200
TARGET_EN_QUERIES = 200
QUERY_COUNT_TOLERANCE = 0.20  # +/-20% counted as "approximately"

VALID_LANGUAGES = {"Hindi", "English"}
VALID_INTENTS = {
    "book_recommendation", "genre_recommendation", "author_search",
    "book_search", "rating_query", "review_query", "book_information",
    "greeting", "help", "goodbye",
}
VALID_SENTIMENTS = {"Positive", "Neutral", "Negative"}
VALID_GENRES = {
    "रोमांस", "रहस्य", "थ्रिलर", "फंतासी", "ऐतिहासिक", "सामाजिक",
    "दार्शनिक", "आत्मकथा", "जीवनी", "प्रेरणादायक", "आध्यात्मिक",
    "मनोविज्ञान", "बाल साहित्य", "कविता", "नाटक", "व्यंग्य", "यात्रा",
    "विज्ञान", "कहानी", "उपन्यास", "हॉरर",
}


def load_csv(path):
    if not os.path.exists(path):
        return None, [f"File not found: {path}"]
    try:
        with open(path, encoding="utf-8") as f:
            reader = csv.DictReader(f)
            rows = list(reader)
    except UnicodeDecodeError:
        return None, [f"File is not valid UTF-8: {path}"]
    return rows, []


def validate_books(path):
    rows, errors = load_csv(path)
    stats = {
        "n_books": 0, "dup_book_ids": {}, "dup_titles": {},
        "missing_title": 0, "missing_author": 0, "missing_language": 0,
        "invalid_language": 0,
    }
    if rows is None:
        return errors, stats, set()

    required_cols = {"book_id", "title", "author", "genre", "rating",
                      "description", "language"}
    if rows and not required_cols.issubset(rows[0].keys()):
        missing = required_cols - set(rows[0].keys())
        errors.append(f"Missing required columns: {missing}")

    id_counter = Counter()
    title_counter = Counter()
    title_author_counter = Counter()
    all_ids = set()

    for i, row in enumerate(rows, start=2):
        book_id = row.get("book_id", "").strip()
        title = row.get("title", "").strip()
        author = row.get("author", "").strip()
        genre = row.get("genre", "").strip()
        desc = row.get("description", "").strip()
        language = row.get("language", "").strip()
        rating = row.get("rating", "").strip()

        all_ids.add(book_id)
        id_counter[book_id] += 1
        title_counter[title] += 1
        title_author_counter[(title, author)] += 1

        if not title:
            errors.append(f"Row {i}: empty title")
            stats["missing_title"] += 1
        if not author:
            stats["missing_author"] += 1
        if not language:
            stats["missing_language"] += 1
        elif language != "Hindi":
            errors.append(f"Row {i}: invalid language '{language}' (expected 'Hindi')")
            stats["invalid_language"] += 1

        if genre and genre not in VALID_GENRES:
            errors.append(f"Row {i}: unrecognized genre '{genre}'")

        if rating:
            try:
                r = float(rating)
                if not (0 <= r <= 5):
                    errors.append(f"Row {i}: invalid rating '{rating}' (must be 0-5 or blank)")
            except ValueError:
                errors.append(f"Row {i}: non-numeric, non-blank rating '{rating}'")

    stats["n_books"] = len(rows)
    stats["dup_book_ids"] = {k: v for k, v in id_counter.items() if v > 1}
    stats["dup_title_author"] = {k: v for k, v in title_author_counter.items() if v > 1}
    # "duplicate titles" = same title text appearing more than once, regardless of author
    stats["dup_titles"] = {k: v for k, v in title_counter.items() if v > 1}

    for bid, count in stats["dup_book_ids"].items():
        errors.append(f"Duplicate book_id '{bid}' appears {count} times")
    for (t, a), count in stats["dup_title_author"].items():
        errors.append(f"Duplicate title-author combination '{t}' / '{a}' appears {count} times")

    if stats["n_books"] < MIN_BOOKS:
        errors.append(
            f"Book count {stats['n_books']} is below the minimum target of {MIN_BOOKS}."
        )

    return errors, stats, all_ids


def validate_queries(path, expected_language, target_count):
    rows, errors = load_csv(path)
    if rows is None:
        return errors, 0

    required_cols = {"query", "language", "intent"}
    if rows and not required_cols.issubset(rows[0].keys()):
        missing = required_cols - set(rows[0].keys())
        errors.append(f"Missing required columns: {missing}")

    count = 0
    for i, row in enumerate(rows, start=2):
        lang = row.get("language", "").strip()
        intent = row.get("intent", "").strip()
        query = row.get("query", "").strip()

        if not query:
            errors.append(f"Row {i}: empty query")
        if lang not in VALID_LANGUAGES:
            errors.append(f"Row {i}: invalid query language '{lang}'")
        if intent not in VALID_INTENTS:
            errors.append(f"Row {i}: invalid intent '{intent}'")
        if lang == expected_language:
            count += 1

    low = target_count * (1 - QUERY_COUNT_TOLERANCE)
    high = target_count * (1 + QUERY_COUNT_TOLERANCE)
    if not (low <= count <= high):
        errors.append(
            f"{expected_language} query count {count} is outside the "
            f"approximate target range [{int(low)}, {int(high)}] for a target of {target_count}"
        )

    return errors, count


def validate_reviews(path, valid_book_ids):
    rows, errors = load_csv(path)
    if rows is None:
        return errors, 0

    required_cols = {"review_id", "book_id", "review_text", "rating", "sentiment"}
    if rows and not required_cols.issubset(rows[0].keys()):
        missing = required_cols - set(rows[0].keys())
        errors.append(f"Missing required columns: {missing}")

    seen_ids = set()
    for i, row in enumerate(rows, start=2):
        review_id = row.get("review_id", "").strip()
        book_id = row.get("book_id", "").strip()
        text = row.get("review_text", "").strip()
        sentiment = row.get("sentiment", "").strip()
        rating = row.get("rating", "").strip()
        source_type = row.get("source_type", "").strip()

        if not text:
            errors.append(f"Row {i}: empty review_text")
        if review_id in seen_ids:
            errors.append(f"Row {i}: duplicate review_id '{review_id}'")
        seen_ids.add(review_id)
        if sentiment not in VALID_SENTIMENTS:
            errors.append(f"Row {i}: invalid sentiment '{sentiment}'")
        try:
            r = int(rating)
            if not (1 <= r <= 5):
                errors.append(f"Row {i}: invalid rating '{rating}' (must be 1-5)")
        except ValueError:
            errors.append(f"Row {i}: non-numeric rating '{rating}'")
        if book_id not in valid_book_ids:
            errors.append(f"Row {i}: review references book_id '{book_id}' not found in hindi_books.csv")
        if source_type and source_type != "synthetic":
            errors.append(f"Row {i}: unexpected source_type '{source_type}' (expected 'synthetic')")

    return errors, len(rows)


def main():
    print("DATASET VALIDATION")
    print("=" * 18)
    print()

    all_errors = {}

    book_errors, book_stats, book_ids = validate_books(os.path.join(DATA_DIR, "hindi_books.csv"))
    all_errors["Hindi Books"] = book_errors

    hi_errors, n_hi = validate_queries(os.path.join(DATA_DIR, "chatbot_queries.csv"), "Hindi", TARGET_HI_QUERIES)
    all_errors["Hindi Queries"] = hi_errors

    en_errors, n_en = validate_queries(os.path.join(DATA_DIR, "chatbot_queries.csv"), "English", TARGET_EN_QUERIES)
    all_errors["English Queries"] = en_errors

    review_errors, n_reviews = validate_reviews(os.path.join(DATA_DIR, "hindi_book_reviews.csv"), book_ids)
    all_errors["Reviews"] = review_errors

    for label, errs in all_errors.items():
        status = "PASS" if not errs else f"FAIL ({len(errs)} issue(s))"
        print(f"{label}:")
        print(status)
        if errs:
            for e in errs[:10]:
                print(f"  - {e}")
            if len(errs) > 10:
                print(f"  ... and {len(errs) - 10} more")
        print()

    print("SUMMARY")
    print("-" * 7)
    print(f"Total Hindi Books: {book_stats['n_books']}  (minimum: {MIN_BOOKS}, preferred: {TARGET_BOOKS_LOW}-{TARGET_BOOKS_HIGH})")
    print(f"Total Hindi Queries: {n_hi}  (target: ~{TARGET_HI_QUERIES})")
    print(f"Total English Queries: {n_en}  (target: ~{TARGET_EN_QUERIES})")
    print(f"Total Reviews: {n_reviews}")
    print(f"Duplicate book IDs: {len(book_stats['dup_book_ids'])}")
    print(f"Duplicate titles (same title text, any author): {len(book_stats['dup_titles'])}")
    print(f"Duplicate title-author combinations: {len(book_stats['dup_title_author'])}")
    print(f"Missing title: {book_stats['missing_title']}")
    print(f"Missing author: {book_stats['missing_author']}")
    print(f"Missing language: {book_stats['missing_language']}")
    print(f"Invalid language values: {book_stats['invalid_language']}")
    print()

    any_failures = any(errs for errs in all_errors.values())
    print("FINAL VALIDATION RESULT:", "FAIL" if any_failures else "PASS")

    sys.exit(1 if any_failures else 0)


if __name__ == "__main__":
    main()
