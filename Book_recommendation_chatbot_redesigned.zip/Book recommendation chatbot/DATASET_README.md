# Hindi Book Chatbot — Dataset Documentation

**Project:** Multilingual AI-Based Book Recommendation Chatbot Using NLP
**Phase:** Dataset creation and validation (no chatbot / Flask / recommendation
engine code is included in this phase — that is the next phase).

---

## 1. Dataset Purpose

This dataset supports an NLP-based chatbot that recommends **Hindi books**
in response to user queries written in **either Hindi or English**. It has
four parts:

| File | Purpose |
|---|---|
| `data/hindi_books.csv` | The catalog of Hindi books the chatbot recommends from |
| `data/genre_mapping.csv` | Maps Hindi genre labels to English equivalents and keywords |
| `data/chatbot_queries.csv` | Hindi + English example queries labeled with intent/genre/author/title |
| `data/hindi_book_reviews.csv` | Synthetic Hindi reviews with sentiment labels |

## 2. Hindi-Only Book Dataset — Size, Sources, and Description Fill

**`hindi_books.csv` contains 301 real, unique Hindi books by 94 real
Hindi authors** — unchanged from the previous version. **This update did
not add, remove, or modify any book, author, genre, rating, or
publication_year.** It only attempted to fill `description` for the 82
rows that had none.

### What happened in this pass

Each of the 82 books with an empty `description` was individually
researched. For **5 of them**, a genuine, sourced factual summary was
found — not just a title-author listing, but an actual description of
the book's subject or theme, traceable to a specific source:

| book_id | title | author | Source used |
|---|---|---|---|
| 210 | अंकों की कहानी | गुणाकर मुले | hindwi.org book page (publisher, page count, confirms real book on number history) |
| 213 | अंतराल | मोहन राकेश | hindwi.org author profile, bharatdiscovery.org, studyx.ai (plot theme, 1972 posthumous publication) |
| 220 | अछूते फूल और अन्य कहानियां | अज्ञेय | gadyakosh.org (confirms "अछूते फूल" as a genuine Agyeya story; collection is titled after it) |
| 233 | अमृत और विष | अमृतलाल नागर | hi.wikipedia.org dedicated article, testbook.com (plot theme, 1967 Sahitya Akademi Award) |
| 239 | अहिल्या बाई | वृंदावनलाल वर्मा | bharatdiscovery.org, livehistoryindia.com (confirms historical novel on queen Ahilyabai Holkar) |

**For the remaining 77 books, `description` is intentionally left
blank.** For most of them, search only turned up the same kind of
bibliographic listing already used to justify their inclusion in the
dataset (a title-author pair in an index) — with no independent source
describing what the book is actually about. Per your explicit
instruction, a plausible-sounding description was **not** written for
these; guessing at content from a title alone (e.g. assuming "अंकुर"
means the plot is about a sprouting seed) is not verification, so those
rows stay blank rather than risk stating something false about the
book.

### Why so few of 82 were fillable

The books added in the previous expansion round were deliberately picked
from a noisy bibliographic index (see the "Sources Used" note in the
prior version of this file) specifically because their *existence* and
*author attribution* could be verified — that bar is much lower than
finding an actual plot/content summary. Many of these are minor or
regionally-published works with no dedicated Wikipedia article, review,
or publisher blurb indexed by search. Getting descriptions for the rest
would likely require access to a library catalog with abstracts (e.g.
WorldCat, National Library of India) or the physical book itself —
beyond what web search could confirm in this pass.

## 3. Column Reference — `hindi_books.csv`

| Column | Description |
|---|---|
| `book_id` | Sequential integer ID, unique |
| `title` | Book title (Hindi) — unchanged this pass |
| `author` | Author's commonly used name — unchanged this pass |
| `genre` | One Hindi genre label — unchanged this pass |
| `rating` | Blank for every row — no verified real ratings source used |
| `description` | Hindi summary where verifiable; blank otherwise (77 of 301 rows, down from 82) |
| `publication_year` | Blank where not confidently known — unchanged this pass |
| `language` | Always "Hindi" |
| `search_text` | Recomputed for the 5 updated rows to stay consistent with their new description |

`publisher`, `pages`, `series`, `isbn` remain omitted — never verifiable
without fabrication.

## 4. Genre Mapping

`genre_mapping.csv` is unchanged this round — all 18 genres in the book
catalog are already covered.

## 5. Chatbot Queries and Intents

`chatbot_queries.csv` is unchanged this round: **205 Hindi and 205
English** synthetic, template-generated queries (410 total).

## 6. Synthetic Review Disclaimer

`data/hindi_book_reviews.csv` is unchanged this round: **756 synthetic
reviews** (2–3 per book), all `source_type = synthetic`. NOT authentic
Goodreads or user-submitted reviews.

## 7. What's Real vs. Synthetic — Summary

| Data | Real or synthetic |
|---|---|
| Book titles, authors, genres | **Real** — verified against bibliographic sources |
| `description` | Real (sourced fact) for 224 of 301 books; blank for the other 77 — never invented |
| `rating` | Blank (no real source used) |
| `publication_year` | Real where known, blank otherwise |
| `chatbot_queries.csv` | Synthetic (template-generated) |
| `hindi_book_reviews.csv` | Synthetic (`source_type=synthetic`) |

## 8. Recommendation Usage

Intended flow (next phase — the chatbot itself):

1. Detect query language.
2. Classify intent (`genre_recommendation`, `author_search`, etc.).
3. If English, map genre/author terms to the Hindi labels used in
   `hindi_books.csv` via `genre_mapping.csv`.
4. Search **only** `hindi_books.csv` (via `search_text` for TF-IDF /
   cosine similarity, or direct genre/author filtering).
5. Return recommendations drawn only from `hindi_books.csv` — never
   invented titles — in the query's language. For books with a blank
   `description`, the chatbot should fall back to showing title/author/
   genre rather than fabricating a summary at query time.

## 9. Dataset Limitations

- `rating`, `publisher`, `pages`, `series`, `isbn` are not populated.
- `description` is blank for 77 of 301 books — no verifiable summary
  found, left blank rather than invented (see Section 2).
- `publication_year` is blank for the majority of the 93 books added in
  the previous expansion round.
- Genre distribution is uneven — सामाजिक (76) and कविता (56) dominate;
  प्रेरणादायक (1), जीवनी (3), and हॉरर (0) remain thin.
- Queries and reviews are synthetic/template-generated, not from real
  users.

## 10. File Structure

```
hindi_book_chatbot_dataset/
│
├── data/
│   ├── hindi_books.csv
│   ├── chatbot_queries.csv
│   ├── hindi_book_reviews.csv
│   ├── genre_mapping.csv
│   └── dataset_statistics.txt
│
├── validate_dataset.py
└── DATASET_README.md
```

## 11. Validation Results (this version)

```
DATASET VALIDATION
==================

Hindi Books:
PASS

Hindi Queries:
PASS

English Queries:
PASS

Reviews:
PASS

SUMMARY
-------
Total Hindi Books: 301  (minimum: 300, preferred: 300-400)
Total Hindi Queries: 205  (target: ~200)
Total English Queries: 205  (target: ~200)
Total Reviews: 756
Duplicate book IDs: 0
Duplicate titles (same title text, any author): 0
Duplicate title-author combinations: 0
Missing title: 0
Missing author: 0
Missing language: 0
Invalid language values: 0

FINAL VALIDATION RESULT: PASS
```

Run `python3 validate_dataset.py` from the project root to reproduce this.
Note: `validate_dataset.py` does not check `description` completeness —
per your instruction, a blank description is valid data, not an error,
so it is not treated as a validation failure.
