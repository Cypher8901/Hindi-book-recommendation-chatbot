/**
 * script.js
 *
 * Vanilla JavaScript chat client for the Multilingual Hindi Book
 * Recommendation Chatbot.
 *
 * Talks to the EXISTING Flask backend exactly as implemented in app.py:
 *
 *   POST /chat
 *     body:  { "message": "<user text>" }
 *     reply: { "language": "Hindi"|"English", "intent": "...",
 *              "response": "...", "books": [...], "claude_used": bool }
 *     on error: { "error": "..." }  with a 400/500 status code
 *
 * Every book object in `books` comes straight from recommendation.py's
 * _row_to_dict(), so it may or may not include a real value for
 * `description`, `rating`, and `publication_year` -- this file NEVER
 * invents a value for a missing field; it either shows what the
 * backend actually returned or an explicit "not available" label.
 */

(function () {
  "use strict";

  // Shown in the browser console so you can confirm the NEW file loaded.
  console.info("Book chatbot UI script loaded: v3 (MIN_THINKING_TIME = 700 ms per request)");

  const chatArea = document.getElementById("chatArea");
  const chatForm = document.getElementById("chatForm");
  const messageInput = document.getElementById("messageInput");
  const sendBtn = document.getElementById("sendBtn");
  const typingIndicator = document.getElementById("typingIndicator");
  const typingLabel = document.getElementById("typingLabel");
  const languageDot = document.getElementById("languageDot");
  const languageLabel = document.getElementById("languageLabel");
  const clearChatBtn = document.getElementById("clearChatBtn");
  const examplePrompts = document.getElementById("examplePrompts");
  const bookCardTemplate = document.getElementById("bookCardTemplate");
  const welcomeHero = document.getElementById("welcomeHero");

  const CHAT_ENDPOINT = "/chat";

  // ------------------------------------------------------------------
  // Rendering helpers
  // ------------------------------------------------------------------

  function scrollToBottom() {
    chatArea.scrollTop = chatArea.scrollHeight;
  }

  /**
   * Append a plain text message bubble (user or bot) to the chat area.
   * `options.books`, if given, renders book cards below the bubble
   * using `options.language` to pick Hindi/English field labels.
   * NOTE: intent name, detected-language code, Claude usage, book IDs,
   * or any other backend/debug detail are intentionally never rendered
   * here -- only the natural-language `text` and the book data itself.
   */
  function appendMessage(text, sender, options) {
    options = options || {};
    const row = document.createElement("div");
    row.className = "message-row " + sender;

    const bubble = document.createElement("div");
    bubble.className = "message-bubble" + (options.isError ? " error-bubble" : "");
    bubble.textContent = text;

    row.appendChild(bubble);
    chatArea.appendChild(row);

    if (options.books && options.books.length > 0) {
      row.appendChild(buildBookCards(options.books, options.language));
    }

    scrollToBottom();
  }

  /**
   * Book field labels shown on each card, in the same language as the
   * chatbot's response text. Only ever "Hindi" or "English" is passed
   * in (that's all nlp.detect_language ever returns), with English as
   * the safe default.
   */
  const LABELS = {
    Hindi: {
      author: "लेखक: ",
      genre: "श्रेणी: ",
      descriptionUnavailable: "विवरण उपलब्ध नहीं है।",
      rating: "रेटिंग: ",
      year: "प्रकाशन वर्ष: ",
    },
    English: {
      author: "Author: ",
      genre: "Genre: ",
      descriptionUnavailable: "Description not available.",
      rating: "Rating: ",
      year: "Publication Year: ",
    },
  };

  /**
   * Build the "book cards" block for a bot message. Only renders
   * fields the backend actually returned -- description/rating/year
   * are shown only when present, and a missing description is shown
   * as an explicit "not available" label (in the response's own
   * language) rather than left blank or guessed.
   */
  function buildBookCards(books, language) {
    const labels = LABELS[language] || LABELS.English;
    const container = document.createElement("div");
    container.className = "book-cards";

    books.forEach(function (book) {
      const node = bookCardTemplate.content.cloneNode(true);

      const titleEl = node.querySelector(".book-card-title");
      const authorEl = node.querySelector(".book-card-author");
      const genreEl = node.querySelector(".book-card-genre");
      const descEl = node.querySelector(".book-card-description");
      const ratingEl = node.querySelector(".book-card-rating");
      const yearEl = node.querySelector(".book-card-year");

      titleEl.textContent = book.title || "";

      if (book.author) {
        authorEl.textContent = labels.author + book.author;
      } else {
        authorEl.remove();
      }

      if (book.genre) {
        genreEl.textContent = labels.genre + book.genre;
      } else {
        genreEl.remove();
      }

      if (book.description_available && book.description) {
        descEl.textContent = book.description;
      } else {
        descEl.textContent = labels.descriptionUnavailable;
        descEl.classList.add("unavailable");
      }

      // Rating: the current dataset has no book-level ratings, so this
      // is only ever shown when the backend actually returns one --
      // never a fabricated or placeholder value.
      if (book.rating_available && book.rating) {
        ratingEl.textContent = labels.rating + book.rating;
      } else {
        ratingEl.remove();
      }

      if (book.publication_year) {
        yearEl.textContent = labels.year + book.publication_year;
      } else {
        yearEl.remove();
      }

      // Display-only: drop the footer row if neither year nor rating exists.
      const metaEl = node.querySelector(".book-card-meta");
      if (metaEl && !metaEl.querySelector(".book-card-year, .book-card-rating")) {
        metaEl.remove();
      }

      container.appendChild(node);
    });

    return container;
  }

  function setLanguageIndicator(language) {
    languageDot.classList.remove("hindi", "english");
    if (language === "Hindi") {
      languageDot.classList.add("hindi");
      languageLabel.textContent = "Language: Hindi";
    } else if (language === "English") {
      languageDot.classList.add("english");
      languageLabel.textContent = "Language: English";
    } else {
      languageLabel.textContent = "Language: --";
    }
  }

  // UI-only thinking text. Chosen from the script of the user's own
  // message (Devanagari => Hindi), so no extra request is made and the
  // backend's language detection is not involved or slowed down.
  const THINKING_TEXT = { Hindi: "सोच रहा हूँ...", English: "Thinking..." };

  function thinkingTextFor(userText) {
    return /[\u0900-\u097F]/.test(userText) ? THINKING_TEXT.Hindi : THINKING_TEXT.English;
  }

  function showTyping(show, label) {
    if (show && label) typingLabel.textContent = label;
    // Toggling `hidden` (display:none <-> displayed) restarts the CSS
    // fade-in and dot animations on every show, so each prompt gets the
    // full visible animation.
    typingIndicator.hidden = !show;
    scrollToBottom();
  }

  // True while a /chat request is in flight; guards every entry point
  // (form submit and example chips) against concurrent sends.
  let isSending = false;

  function setSending(sending) {
    isSending = sending;
    sendBtn.disabled = sending;
    messageInput.disabled = sending;
    clearChatBtn.disabled = sending;
    examplePrompts.querySelectorAll(".chip").forEach(function (chip) {
      chip.disabled = sending;
    });
  }

  // Minimum time (ms) the "Thinking..." indicator must be VISIBLE for
  // EVERY request. It overlaps with the network request (it is not added
  // after it): a 50 ms backend => indicator stays ~700 ms in total; a
  // 2 s backend => indicator is hidden as soon as the reply arrives.
  const MIN_THINKING_TIME = 700;

  function sleep(ms) {
    return new Promise(function (resolve) { setTimeout(resolve, ms); });
  }

  /**
   * Resolves once MIN_THINKING_TIME has passed since `thinkingStartTime`
   * (a Date.now() value taken by the CALLER for this one request).
   * Resolves immediately if that much time has already passed. It holds
   * no state of its own, so it behaves identically for message 1, 20 or
   * 100. The clock is re-checked after every timer because browsers can
   * fire timers slightly early.
   */
  async function waitForMinThinkingTime(thinkingStartTime) {
    let remaining = MIN_THINKING_TIME - (Date.now() - thinkingStartTime);
    while (remaining > 0) {
      await sleep(remaining);
      remaining = MIN_THINKING_TIME - (Date.now() - thinkingStartTime);
    }
  }

  // ------------------------------------------------------------------
  // Networking
  // ------------------------------------------------------------------

  /**
   * Talk to the real /chat endpoint. This ONLY performs the request and
   * classifies the outcome -- it never touches the DOM -- so that
   * sendMessage() can decide WHEN to hide the indicator and WHEN to
   * show the result. Never throws; always returns one of:
   *   { kind: "ok",      data }       successful reply
   *   { kind: "error",   message }    HTTP error with the server's message
   *   { kind: "network", error }      server unreachable / unreadable reply
   */
  async function requestChat(text) {
    try {
      const res = await fetch(CHAT_ENDPOINT, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: text }),
      });

      let data;
      try {
        data = await res.json();
      } catch (parseErr) {
        return { kind: "network", error: new Error("The server sent back a response that couldn't be read.") };
      }

      if (!res.ok) {
        const message = (data && data.error) ? data.error
          : "Something went wrong (HTTP " + res.status + ").";
        return { kind: "error", message: message };
      }
      return { kind: "ok", data: data };
    } catch (err) {
      return { kind: "network", error: err };
    }
  }

  function renderOutcome(outcome) {
    if (outcome.kind === "ok") {
      const data = outcome.data;
      setLanguageIndicator(data.language);
      appendMessage(data.response || "", "bot", {
        language: data.language,
        books: Array.isArray(data.books) ? data.books : [],
      });
    } else if (outcome.kind === "error") {
      appendMessage(outcome.message, "bot", { isError: true });
    } else {
      appendMessage(
        "Could not reach the chatbot server. Please make sure the Flask " +
        "app (app.py) is running, then try again.",
        "bot",
        { isError: true }
      );
      console.error("Chat request failed:", outcome.error);
    }
  }

  /**
   * Send `text` and render the reply. Order for EVERY call:
   *
   *   user bubble -> Thinking shown -> /chat request (in flight)
   *     -> reply received -> wait until 700 ms since THIS call started
   *     -> Thinking hidden -> chatbot reply appears
   *
   * `thinkingStartTime` is a local const: every call gets its own timer.
   * There is no module-level "first request" flag or shared timer.
   */
  async function sendMessage(text) {
    if (isSending) return;   // ignore any send while a request is running

    if (welcomeHero) welcomeHero.hidden = true;   // start screen only shows before the first message
    appendMessage(text, "user");

    const thinkingStartTime = Date.now();         // fresh timer for THIS request
    setSending(true);
    showTyping(true, thinkingTextFor(text));

    try {
      const outcome = await requestChat(text);                 // 1) real request
      await waitForMinThinkingTime(thinkingStartTime);         // 2) overlap-aware minimum
      showTyping(false);                                       // 3) hide indicator ...
      renderOutcome(outcome);                                  // 4) ... THEN show the reply
    } catch (err) {
      // Safety net (e.g. an exception while rendering): still honour the
      // minimum, always hide the indicator, and tell the user.
      await waitForMinThinkingTime(thinkingStartTime);
      showTyping(false);
      appendMessage("Something went wrong while showing the reply. Please try again.", "bot", { isError: true });
      console.error("Unexpected chat UI error:", err);
    } finally {
      setSending(false);     // unlock input / buttons on every path
      showTyping(false);     // belt and braces: never leave it showing
      messageInput.focus();
    }
  }

  // ------------------------------------------------------------------
  // Event wiring
  // ------------------------------------------------------------------

  chatForm.addEventListener("submit", function (event) {
    event.preventDefault();
    if (isSending) return;
    const text = messageInput.value.trim();

    // Requirement: handle empty input -- simply do not send a request,
    // and give a lightweight visual nudge instead of a silent no-op.
    if (!text) {
      messageInput.focus();
      messageInput.classList.add("input-shake");
      setTimeout(function () { messageInput.classList.remove("input-shake"); }, 300);
      return;
    }

    messageInput.value = "";
    sendMessage(text);
  });

  clearChatBtn.addEventListener("click", function () {
    // Clears the on-screen conversation only. The backend's own
    // conversation memory lives server-side in the Flask session
    // (see app.py / chatbot.py) and there is no reset endpoint for it
    // in the existing API, so this intentionally only clears the UI.
    chatArea.innerHTML = "";
    if (welcomeHero) welcomeHero.hidden = false;
    setLanguageIndicator(null);
    appendMessage(
      "Chat cleared. Ask me about a book, genre, or author in Hindi or English!",
      "bot"
    );
  });

  examplePrompts.addEventListener("click", function (event) {
    const chip = event.target.closest(".chip");
    if (!chip) return;
    const prompt = chip.getAttribute("data-prompt");
    if (!prompt) return;
    sendMessage(prompt);
  });

  // Initial greeting shown purely in the UI (not a real backend call,
  // just a static welcome so the chat area isn't empty on first load).
  appendMessage(
    "नमस्ते! मुझसे हिंदी किताबों के बारे में पूछें — Ask me about Hindi books in Hindi or English!",
    "bot"
  );
})();
